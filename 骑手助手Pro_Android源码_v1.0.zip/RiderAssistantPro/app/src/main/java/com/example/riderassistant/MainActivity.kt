package com.example.riderassistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

class MainActivity : ComponentActivity() {
    private lateinit var locationManager: LocationManager
    private var listener: LocationListener? = null
    private var permissionGranted by mutableStateOf(false)
    private var latestLocation by mutableStateOf<Location?>(null)
    private var locationStatus by mutableStateOf("尚未开始检测")
    private var driftMeters by mutableStateOf(0f)
    private var previousLocation: Location? = null
    private var isTracking by mutableStateOf(false)
    private var isOnlineLog by mutableStateOf(false)
    private var sessionStart by mutableStateOf<Long?>(null)
    private var records by mutableStateOf(listOf<String>())

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            permissionGranted =
                result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
            if (permissionGranted) startLocationTracking()
            else locationStatus = "未获得定位权限；可在系统设置中授权"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        loadRecords()
        permissionGranted = hasLocationPermission()
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Dashboard(
                        status = locationStatus,
                        location = latestLocation,
                        drift = driftMeters,
                        tracking = isTracking,
                        onlineLog = isOnlineLog,
                        records = records,
                        onStartLocation = { requestOrStartLocation() },
                        onStopLocation = { stopLocationTracking() },
                        onOnlineToggle = { toggleOnlineLog() },
                        onNotificationSettings = { openNotificationSettings() },
                        onLocationSettings = { startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) },
                        onClearRecords = { clearRecords() }
                    )
                }
            }
        }
    }

    private fun hasLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun requestOrStartLocation() {
        if (!hasLocationPermission()) {
            permissionLauncher.launch(arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ))
        } else startLocationTracking()
    }

    @Suppress("MissingPermission")
    private fun startLocationTracking() {
        if (!hasLocationPermission()) return
        stopLocationTracking()
        val providers = locationManager.getProviders(true)
            .filter { it == LocationManager.GPS_PROVIDER || it == LocationManager.NETWORK_PROVIDER }

        if (providers.isEmpty()) {
            locationStatus = "系统未提供可用定位源，请检查手机定位开关"
            return
        }

        val newListener = LocationListener { loc ->
            val old = previousLocation
            if (old != null) driftMeters = old.distanceTo(loc)
            previousLocation = loc
            latestLocation = loc
            locationStatus = when {
                loc.accuracy <= 10f -> "定位良好"
                loc.accuracy <= 30f -> "定位一般"
                else -> "定位精度较低"
            }
        }
        listener = newListener
        try {
            providers.forEach { provider ->
                locationManager.requestLocationUpdates(
                    provider, 2500L, 0f, newListener, Looper.getMainLooper()
                )
                locationManager.getLastKnownLocation(provider)?.let { loc ->
                    latestLocation = loc
                    previousLocation = loc
                    locationStatus = "已取得最近一次定位，等待实时更新"
                }
            }
            isTracking = true
            if (latestLocation == null) locationStatus = "正在等待 GPS 信号…"
        } catch (e: SecurityException) {
            locationStatus = "定位权限不足，请重新授权"
        } catch (e: Exception) {
            locationStatus = "启动定位失败：${e.localizedMessage ?: "未知错误"}"
        }
    }

    private fun stopLocationTracking() {
        listener?.let { locationManager.removeUpdates(it) }
        listener = null
        isTracking = false
    }

    private fun toggleOnlineLog() {
        val now = System.currentTimeMillis()
        if (!isOnlineLog) {
            isOnlineLog = true
            sessionStart = now
            addRecord("上线记录开始")
        } else {
            val elapsed = sessionStart?.let { max(0L, now - it) } ?: 0L
            val mins = elapsed / 60000L
            isOnlineLog = false
            sessionStart = null
            addRecord("下线记录结束 · 本次 ${mins / 60}小时${mins % 60}分钟")
        }
    }

    private fun addRecord(value: String) {
        val stamp = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date())
        records = listOf("$stamp · $value") + records
        saveRecords()
    }

    private fun saveRecords() {
        getSharedPreferences("rider_helper", MODE_PRIVATE)
            .edit().putString("records", JSONArray(records).toString()).apply()
    }

    private fun loadRecords() {
        val raw = getSharedPreferences("rider_helper", MODE_PRIVATE).getString("records", "[]")
        records = try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (_: Exception) { emptyList() }
    }

    private fun clearRecords() {
        records = emptyList()
        saveRecords()
    }

    private fun openNotificationSettings() {
        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
        startActivity(intent)
    }

    override fun onPause() {
        super.onPause()
        // 为节省电量，首版仅在应用前台持续检测。
        stopLocationTracking()
    }
}

@Composable
private fun Dashboard(
    status: String,
    location: Location?,
    drift: Float,
    tracking: Boolean,
    onlineLog: Boolean,
    records: List<String>,
    onStartLocation: () -> Unit,
    onStopLocation: () -> Unit,
    onOnlineToggle: () -> Unit,
    onNotificationSettings: () -> Unit,
    onLocationSettings: () -> Unit,
    onClearRecords: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBarCompat()
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text("定位状态", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(6.dp))
                        Text(status, color = MaterialTheme.colorScheme.primary)
                        Text(if (tracking) "检测中 · 应用在前台时更新" else "检测已停止")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = onStartLocation) { Text("开始检测") }
                            OutlinedButton(onClick = onStopLocation) { Text("停止") }
                        }
                    }
                }
            }
            item {
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text("实时定位数据", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(8.dp))
                        DataLine("纬度", location?.latitude?.let { "%.6f".format(it) } ?: "--")
                        DataLine("经度", location?.longitude?.let { "%.6f".format(it) } ?: "--")
                        DataLine("水平精度", location?.accuracy?.let { "约 ${it.toInt()} 米" } ?: "--")
                        DataLine("两次定位点间距", if (location == null) "--" else "约 ${drift.toInt()} 米")
                        DataLine("定位来源", location?.provider ?: "--")
                        DataLine("更新时间", location?.time?.let {
                            SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(it))
                        } ?: "--")
                        Text(
                            "提示：两次定位点间距不等于 GPS 误差；精度值由 Android 定位服务提供。",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            item {
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text("工作时间记录", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(5.dp))
                        Text(if (onlineLog) "记录状态：正在记录上线时段" else "记录状态：未开始")
                        Button(onClick = onOnlineToggle) {
                            Text(if (onlineLog) "结束本次记录" else "开始上线记录")
                        }
                    }
                }
            }
            item {
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text("快捷设置", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = onLocationSettings, modifier = Modifier.fillMaxWidth()) {
                            Text("打开手机定位设置")
                        }
                        OutlinedButton(onClick = onNotificationSettings, modifier = Modifier.fillMaxWidth()) {
                            Text("打开本应用通知设置")
                        }
                        Text(
                            "此按钮只管理本工具自身的通知设置，不会读取、屏蔽或修改美团众包通知。",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("本地工作记录", style = MaterialTheme.typography.titleLarge)
                    TextButton(onClick = onClearRecords) { Text("清空") }
                }
            }
            if (records.isEmpty()) {
                item { Text("暂无记录", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            } else {
                items(records) { record ->
                    Card { Text(record, Modifier.padding(12.dp)) }
                }
            }
            item {
                Text(
                    "隐私说明：定位只在本工具前台检测时读取，工作记录保存在本机。首版不连接美团众包，也不修改其他应用的位置数据。",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun TopAppBarCompat() {
    Surface(shadowElevation = 2.dp) {
        Text("骑手助手 Pro", Modifier.fillMaxWidth().padding(18.dp), style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
private fun DataLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value)
    }
}
