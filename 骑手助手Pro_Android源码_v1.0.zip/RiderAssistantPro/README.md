# 骑手助手 Pro（Android 源代码 v1.0）

这是一个独立的 Android 定位诊断与工作时段记录工具。它不连接美团众包，不修改其他应用的定位数据，也不承诺影响平台派单。

## 功能
- Android GPS / 网络定位状态检测
- 经纬度、定位精度、定位来源和更新时间显示
- 相邻定位点距离提示（不是 GPS 误差值）
- 手动开始/结束上线时段记录
- 本地保存工作记录
- 快捷打开系统定位设置和本工具通知设置

## 环境
- Android Studio（建议最新版稳定版）
- JDK 17
- Android SDK 35
- 最低 Android 10（API 29）

## 打开与编译
1. 解压项目。
2. Android Studio 选择 `Open`，打开 `RiderAssistantPro` 文件夹。
3. 等待 Gradle Sync 完成。
4. 连接安卓手机，开启开发者选项和 USB 调试。
5. 点击 Run 安装到手机。
6. 如需 APK：`Build > Build Bundle(s) / APK(s) > Build APK(s)`。
7. APK 通常生成在 `app/build/outputs/apk/debug/app-debug.apk`。

## 权限与隐私
首次点击“开始检测”时申请精确/大致位置权限。定位只在应用前台检测；应用进入后台时停止更新以节省电量。记录使用 SharedPreferences 保存在本机。

## 说明
本项目是源代码工程，不是已签名发布版 APK。需要使用 Android Studio / Gradle 编译生成 APK。
